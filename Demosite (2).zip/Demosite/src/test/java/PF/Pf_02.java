package PF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_02 {

	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(name="add-to-cart-sauce-labs-bolt-t-shirt") WebElement add;
	@FindBy(className="shopping_cart_link") WebElement icon;
	@FindBy(id="continue-shopping") WebElement contue;
	WebDriver driver;
 
	public Pf_02(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void username(String usname) throws InterruptedException {
		user.sendKeys(usname);
		Thread.sleep(1000);
	}
	public void password(String psswd) throws InterruptedException {
		passwd.sendKeys(psswd);
		Thread.sleep(1000);
	}
	public void submit() throws InterruptedException {
		login.click();
		Thread.sleep(1000);
	}
	public void addcart() throws InterruptedException {
		add.click();
		Thread.sleep(1000);
	}
	public void carticon() throws InterruptedException {
		icon.click();
		Thread.sleep(1000);
	}
	public void continueshop() {
		contue.click();
	}
}

	

