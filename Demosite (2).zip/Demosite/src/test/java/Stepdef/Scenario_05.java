package Stepdef;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import PF.Pf_05;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Scenario_05 {
	
	WebDriver driver;
	Pf_05 log;
	List<WebElement> price;
	
	@Given("User should be able to lauch the website")
	public void user_should_be_able_to_lauch_the_website() {
		System.setProperty("webdriver.edge.driver","C:\\Windows\\System32\\config\\systemprofile\\eclipseProject\\Demosite\\Driver\\msedgedriver.exe");
	    driver = new EdgeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://www.saucedemo.com");
	   
	}

	@When("User should enters the login credentials")
	public void user_should_enters_the_login_credentials() throws InterruptedException {
		log = new Pf_05(driver);
	    log.user("standard_user","secret_sauce");
	    
	}

	@And("User should be able to select filter")
	public void user_should_be_able_to_select_filter() {
	}

	@And("User should be able to view the sorted product")
	public void user_should_be_able_to_view_the_sorted_product() {
	
		ArrayList<String> beforeprice=new ArrayList<String>();
		price=log.price;
		for(WebElement we:price)
		{
			beforeprice.add(we.getText());
		}
		Collections.sort(beforeprice);
		Collections.reverse(beforeprice);

		Select s=new Select(driver.findElement(By.className("product_sort_container")));
	    s.selectByVisibleText("Name (Z to A)");
	    System.out.println(beforeprice);
		ArrayList<String> afterPrice=new ArrayList<String>();
		price=log.price;
		for(WebElement p:price)
		{
			afterPrice.add(p.getText());
		}
		System.out.println(afterPrice);
		 Assert.assertEquals(beforeprice, afterPrice);    
	}
	   
	@And("User should be able to add multiple products")
	public void user_should_be_able_to_add_multiple_products() throws InterruptedException {
	    log.addcart();
	}

	@And("User should be able to view added items")
	public void user_should_be_able_to_view_added_items() {
		
	    WebElement title = driver.findElement(By.xpath("//span[text()='2']"));
        String ExpectedText = "2";
		Assert.assertEquals(ExpectedText, title.getText());
		System.out.println("Number of the product in cart is same");
	      
	}

	@And("User should be able to click on reset the cart")
	public void user_should_be_able_to_click_on_reset_the_cart() throws InterruptedException {
	    log.openmenu();
	}

	@And("User should be able to empty the cart")
	public void user_should_be_able_to_empty_the_cart() {
		WebElement itemdisplay = driver.findElement(By.cssSelector("a.shopping_cart_link"));
		Assert.assertEquals(true, itemdisplay.isDisplayed());
		System.out.println("The cart is empty");
     
	}

	@Then("User should be able to perform logout")
	public void user_should_be_able_to_perform_logout() throws InterruptedException {
	    log.logout();
	}
}
