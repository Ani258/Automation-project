package PF;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_04 {

	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(name="add-to-cart-sauce-labs-onesie") WebElement prod1 ;
	@FindBy(name="add-to-cart-sauce-labs-bike-light") WebElement prod2 ;
	@FindBy(className="shopping_cart_link") WebElement icon;
	@FindBy(css=".inventory_item_price")
	public List<WebElement> price;
	@FindBy(id="checkout") WebElement check;
	@FindBy(id="first-name") WebElement fn;
	@FindBy(id="last-name") WebElement ln;
	@FindBy(id="postal-code") WebElement zipcode;
	@FindBy(name="continue") WebElement cntue;
	@FindBy(xpath="//button[text()='Finish']") WebElement finish;
	@FindBy(id="back-to-products") WebElement back;
	
	WebDriver driver;
	 
	public Pf_04(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void user(String usrname,String paswrd) throws InterruptedException {
		user.sendKeys(usrname);
		passwd.sendKeys(paswrd);
		login.click();
		Thread.sleep(1000);
	}

	public void addcart() throws InterruptedException {
		prod1.click();
		prod2.click();
		Thread.sleep(2000);
	}

	public void carticon() throws InterruptedException {
		icon.click();
		Thread.sleep(2000);
	}

	public void checkout() throws InterruptedException {
		check.click();
		Thread.sleep(1000);
	}
	public void details(String fname,String lname) throws InterruptedException {
		fn.sendKeys(fname);
		ln.sendKeys(lname);
		zipcode.sendKeys("62879");
		Thread.sleep(1000);
		
	}
	public void contine() throws InterruptedException {
		cntue.click();
		Thread.sleep(1000);
	}
	public void Finishbutton() throws InterruptedException {
		finish.click();
		Thread.sleep(1000);
	}
	public void backhome() {
		back.click();
	}
}
