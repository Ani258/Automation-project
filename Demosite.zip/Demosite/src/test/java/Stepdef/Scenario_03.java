package Stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PF.Pf_02;
import PF.Pf_03;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Scenario_03 {

	WebDriver driver;
	Pf_03 log;
	
	@Given("User should be able to lauch the saucelab demosite")
	public void user_should_be_able_to_lauch_the_saucelab_demosite() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Windows\\System32\\config\\systemprofile\\eclipseProject\\Demosite\\Driver\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://www.saucedemo.com");
	    log = new Pf_03(driver);
	    Thread.sleep(2000);
	    throw new io.cucumber.java.PendingException();
	}

	@When("User should enters the username")
	public void user_should_enters_the_username() {
	    log.username();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should enters the password")
	public void user_should_enters_the_password() {
	    log.password();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to login the home page")
	public void user_should_be_able_to_login_the_home_page() {
	    log.submit();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should add 3rd product to the cart")
	public void user_should_add_3rd_product_to_the_cart() {
	    log.addcart();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should add 1st product to the cart")
	public void user_should_add_1st_product_to_the_cart() {
	    log.addcart1();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User navigates to cart page")
	public void user_navigates_to_cart_page() {
	    log.carticon();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to view the selected item in the cart")
	public void user_should_be_able_to_view_the_selected_item_in_the_cart() {
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to click on remove button of 2nd product from the cart")
	public void user_should_be_able_to_click_on_remove_button_of_2nd_product_from_the_cart() {
	    log.removebutton();
	    throw new io.cucumber.java.PendingException();
	}

	@Then("User should be able to remove 2nd item from the cart")
	public void user_should_be_able_to_remove_2nd_item_from_the_cart() {
	    log.removeproduct();
	    throw new io.cucumber.java.PendingException();
	}


}
