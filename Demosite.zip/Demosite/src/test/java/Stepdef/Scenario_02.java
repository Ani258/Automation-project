package Stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import PF.Pf_02;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Scenario_02 {
	
	WebDriver driver;
	Pf_02 log;
	
	@Given("User should be able to lauch the saucelab page")
	public void user_should_be_able_to_lauch_the_saucelab_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Windows\\System32\\config\\systemprofile\\eclipseProject\\Demosite\\Driver\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://www.saucedemo.com");
	    log = new Pf_02(driver);
	    Thread.sleep(2000);
	    throw new io.cucumber.java.PendingException();
	}

	@When("User should be able to give the username")
	public void user_should_be_able_to_give_the_username() {
	    log.username();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to give the password")
	public void user_should_be_able_to_give_the_password() {
	    log.addcart();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to login the Swag labs")
	public void user_should_be_able_to_login_the_swag_labs() {
	    log.submit();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to add 3rd product to the cart")
	public void user_should_be_able_to_add_3rd_product_to_the_cart() {
	    log.addcart();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be navigate to cart page")
	public void user_should_be_navigate_to_cart_page() {
	    log.carticon();
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to view the selected item in the cart and price must be same as it is displaye in home page")
	public void user_should_be_able_to_view_the_selected_item_in_the_cart_and_price_must_be_same_as_it_is_displaye_in_home_page() {
		WebElement itemdisplay = driver.findElement(By.linkText("Test.allTheThings() T-Shirt (Red)"));
		Assert.assertEquals(true, itemdisplay.isDisplayed());
		System.out.println("Selected item is present ");
 
		WebElement title = driver.findElement(By.partialLinkText("Test.allTheThings()"));
		String ExpectedText = "Test.allTheThings() T-Shirt (Red)";
		Assert.assertEquals(ExpectedText, title.getText());
		System.out.println("Title of the product is same");
	    throw new io.cucumber.java.PendingException();
	}

	@And("User should be able to click on Continue shopping button")
	public void user_should_be_able_to_click_on_continue_shopping_button() {
	    log.continueshop();
	    throw new io.cucumber.java.PendingException();
	}

	@Then("User should be navigated back to home page")
	public void user_should_be_navigated_back_to_home_page() {
	    throw new io.cucumber.java.PendingException();
	}


}
