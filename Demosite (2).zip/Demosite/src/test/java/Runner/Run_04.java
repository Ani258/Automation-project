package Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
	    features={"C:\\Windows\\System32\\config\\systemprofile\\eclipseProject\\Demosite\\src\\test\\java\\Feature\\Login_04.feature"},
	        glue={"Stepdef"},plugin= {"pretty","html:target/Login04_report.html"}
	
	)

public class Run_04 {

}
