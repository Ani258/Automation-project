package PF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_01 {

	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(name="add-to-cart-test.allthethings()-t-shirt-(red)") WebElement add;
	@FindBy(className="shopping_cart_link") WebElement icon;

	WebDriver driver;
 
	public Pf_01(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void username(String usname) throws InterruptedException {
		user.sendKeys(usname);
		Thread.sleep(1000);
		
	}
	public void password(String pswd) throws InterruptedException {
		passwd.sendKeys(pswd);
		Thread.sleep(1000);
	}
	public void submit() throws InterruptedException {
		login.click();
		Thread.sleep(1000);
	}
	public void addcart() throws InterruptedException {
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		//js.executeScript("windows.scrollBy(0,120)");
		add.click();
		Thread.sleep(2000);
	}
	public void carticon() {
		icon.click();
	}
}
