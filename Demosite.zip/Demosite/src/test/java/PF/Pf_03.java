package PF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_03 {
	
	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(name="add-to-cart-sauce-labs-bolt-t-shirt") WebElement add3;
	@FindBy(name="add-to-cart-sauce-labs-backpack") WebElement add1;
	@FindBy(className="shopping_cart_link") WebElement icon;
	@FindBy(name="remove-sauce-labs-backpack") WebElement removebtn;
	@FindBy(xpath="//div[text()='Sauce Labs Backpack']") WebElement remove;
	@FindBy(name="remove-sauce-labs-backpack") WebElement remove1;
	WebDriver driver;
 
	public Pf_03(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void username() {
		user.sendKeys("standard_user");
	}
	public void password() {
		passwd.sendKeys("secret_sauce");
	}
	public void submit() {
		login.click();
	}
	public void addcart() {
		add3.click();
	}
	public void addcart1() {
		add1.click();
	}
	public void carticon() {
		icon.click();
	}
	public void removebutton() {
		removebtn.click();
	}
	public void removeproduct() {
		remove.click();
		remove1.click();
	}

}
