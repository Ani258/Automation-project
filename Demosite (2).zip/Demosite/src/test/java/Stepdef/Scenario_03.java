package Stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;

import PF.Pf_03;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Scenario_03 {

	WebDriver driver;
	Pf_03 log;
	
	@Given("User should be able to lauch the saucelab demosite")
	public void user_should_be_able_to_lauch_the_saucelab_demosite() throws InterruptedException {
		System.setProperty("webdriver.edge.driver","C:\\Windows\\System32\\config\\systemprofile\\eclipseProject\\Demosite\\Driver\\msedgedriver.exe");
	    driver = new EdgeDriver();
	    driver.manage().window().maximize();
	    driver.get("https://www.saucedemo.com");
	    
	}

	@When("User should enters the username")
	public void user_should_enters_the_username() throws InterruptedException {
		log = new Pf_03(driver);
	    log.username("standard_user");
	   
	}

	@And("User should enters the password")
	public void user_should_enters_the_password() throws InterruptedException {
	    log.password("secret_sauce");
	    
	}

	@And("User should be able to login the home page")
	public void user_should_be_able_to_login_the_home_page() throws InterruptedException {
	    log.submit();
	    
	}

	@And("User should add 3rd product to the cart")
	public void user_should_add_3rd_product_to_the_cart() throws InterruptedException {
	    log.addcart();
	    
	}

	@And("User should add 1st product to the cart")
	public void user_should_add_1st_product_to_the_cart() throws InterruptedException {
	    log.addcart1();
	    
	}

	@And("User navigates to cart page")
	public void user_navigates_to_cart_page() throws InterruptedException {
	    log.carticon();
	    
	}

	@And("User should be able to view the selected item in the cart")
	public void user_should_be_able_to_view_the_selected_item_in_the_cart() {
		WebElement product1= driver.findElement(By.linkText("Sauce Labs Bolt T-Shirt"));
		Assert.assertEquals(true, product1.isDisplayed());
		System.out.println("Selected Product1 is displayed ");
		
		WebElement product2 = driver.findElement(By.xpath("//div[text()='Sauce Labs Backpack']"));
		Assert.assertEquals(true, product2.isDisplayed());
		System.out.println("Selected product2 is displayed ");
         
	}

	@And("User should be able to click on remove button of 2nd product from the cart")
	public void user_should_be_able_to_click_on_remove_button_of_2nd_product_from_the_cart() throws InterruptedException {
	    log.removebutton();
	    
	}

	@Then("User should be able to remove 2nd item from the cart")
	public void user_should_be_able_to_remove_2nd_item_from_the_cart() {
		WebElement product1= driver.findElement(By.linkText("Sauce Labs Bolt T-Shirt"));
		Assert.assertEquals(true, product1.isDisplayed());
		System.out.println("Selected Product is removed");
	   
	}


}
