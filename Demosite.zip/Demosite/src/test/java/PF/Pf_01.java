package PF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_01 {

	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(xpath="//*[@id=\"inventory_container\"]/div/div[6]/div[3]/button") WebElement add;
	@FindBy(className="shopping_cart_link") WebElement icon;

	WebDriver driver;
 
	public Pf_01(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void username() {
		user.sendKeys("standard_user");
	}
	public void password() {
		passwd.sendKeys("secret_sauce");
	}
	public void submit() {
		login.click();
	}
	public void addcart() {
		add.clear();
	}
	public void carticon() {
		icon.click();
	}
}
