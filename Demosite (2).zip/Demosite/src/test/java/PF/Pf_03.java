package PF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_03 {
	
	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(name="add-to-cart-sauce-labs-bolt-t-shirt") WebElement add3;
	@FindBy(name="add-to-cart-sauce-labs-backpack") WebElement add1;
	@FindBy(className="shopping_cart_link") WebElement icon;
	@FindBy(name="remove-sauce-labs-backpack") WebElement removebtn;
	
	WebDriver driver;
 
	public Pf_03(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void username(String usrname) throws InterruptedException {
		user.sendKeys(usrname);
		Thread.sleep(1000);
	}
	public void password(String paswrd) throws InterruptedException {
		passwd.sendKeys(paswrd);
		Thread.sleep(1000);
	}
	public void submit() throws InterruptedException {
		login.click();
		Thread.sleep(1000);
	}
	public void addcart() throws InterruptedException {
		add3.click();
		Thread.sleep(1000);
	}
	public void addcart1() throws InterruptedException {
		add1.click();
		Thread.sleep(1000);
	}
	public void carticon() throws InterruptedException {
		icon.click();
		Thread.sleep(1000);
	}
	public void removebutton() throws InterruptedException {
		removebtn.click();
		Thread.sleep(1000);
	}


}
