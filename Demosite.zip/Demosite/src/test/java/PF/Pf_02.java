package PF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pf_02 {

	@FindBy(id="user-name") WebElement user;
	@FindBy(id="password") WebElement passwd;
	@FindBy(id="login-button") WebElement login;
	@FindBy(name="add-to-cart-sauce-labs-bolt-t-shirt") WebElement add;
	@FindBy(className="shopping_cart_link") WebElement icon;
	@FindBy(id="continue-shopping") WebElement contue;
	WebDriver driver;
 
	public Pf_02(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void username() {
		user.sendKeys("standard_user");
	}
	public void password() {
		passwd.sendKeys("secret_sauce");
	}
	public void submit() {
		login.click();
	}
	public void addcart() {
		add.click();
	}
	public void carticon() {
		icon.click();
	}
	public void continueshop() {
		contue.click();
	}
}

	

